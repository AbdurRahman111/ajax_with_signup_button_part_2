from django.contrib import admin
from .models import Videos,About,Agents,Easysafe,Message
# Register your models here.

admin.site.register(Videos)
admin.site.register(About)
admin.site.register(Agents)
admin.site.register(Easysafe)
admin.site.register(Message)