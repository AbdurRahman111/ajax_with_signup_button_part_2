from django.apps import AppConfig


class ListvehicleConfig(AppConfig):
    name = 'listvehicle'
