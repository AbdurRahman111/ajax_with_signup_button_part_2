﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ru",{title:"Выбор цвета интерфейса",preview:"Предпросмотр в реальном времени",config:"Вставьте эту строку в файл config.js",predefined:"Предопределенные цветовые схемы"});